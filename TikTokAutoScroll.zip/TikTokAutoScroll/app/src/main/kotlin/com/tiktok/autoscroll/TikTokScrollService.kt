package com.tiktok.autoscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TikTokScrollService : AccessibilityService() {

    companion object {
        // Keywords that indicate a TikTok video has ended / is replaying
        private val REPLAY_KEYWORDS = setOf(
            "replay", "watch again", "再播放", "重播"
        )
        var isRunning = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastScrollTime = 0L
    private val scrollCooldownMs = 2000L  // Prevent double-swipes

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isRunning) return
        event ?: return

        val packageName = event.packageName?.toString() ?: return
        if (!isTikTok(packageName)) return

        // Only act on content changes (video state updates)
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

        val root = rootInActiveWindow ?: return
        if (hasReplayIndicator(root)) {
            scrollToNext()
        }
        root.recycle()
    }

    private fun isTikTok(pkg: String) = pkg in setOf(
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill",
        "com.ss.android.ugc.aweme"
    )

    /**
     * Walk the accessibility tree looking for any node whose text or
     * content-description signals "video ended / replay".
     */
    private fun hasReplayIndicator(node: AccessibilityNodeInfo): Boolean {
        val text = node.text?.toString()?.lowercase()
        val desc = node.contentDescription?.toString()?.lowercase()

        if (text != null && REPLAY_KEYWORDS.any { text.contains(it) }) return true
        if (desc != null && REPLAY_KEYWORDS.any { desc.contains(it) }) return true

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (hasReplayIndicator(child)) {
                child.recycle()
                return true
            }
            child.recycle()
        }
        return false
    }

    private fun scrollToNext() {
        val now = System.currentTimeMillis()
        if (now - lastScrollTime < scrollCooldownMs) return
        lastScrollTime = now

        // Small delay so TikTok finishes its own animation first
        handler.postDelayed({ performSwipeUp() }, 400)
    }

    /**
     * Swipe from bottom-center to top-center — TikTok's "next video" gesture.
     */
    private fun performSwipeUp() {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels

        val startX = w / 2f
        val startY = h * 0.80f
        val endY   = h * 0.20f

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(startX, endY)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0, 300)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onInterrupt() {
        isRunning = false
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        handler.removeCallbacksAndMessages(null)
    }
}
