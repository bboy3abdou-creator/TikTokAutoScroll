package com.tiktok.autoscroll

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var actionButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText   = findViewById(R.id.statusText)
        actionButton = findViewById(R.id.actionButton)

        actionButton.setOnClickListener {
            if (isAccessibilityEnabled()) {
                // Open accessibility settings so user can turn it off
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun updateUI() {
        if (isAccessibilityEnabled()) {
            statusText.text   = "✅ Auto-scroll is ON"
            actionButton.text = "Disable Service"
            actionButton.setBackgroundColor(getColor(R.color.red))
        } else {
            statusText.text   = "⭕ Auto-scroll is OFF"
            actionButton.text = "Enable Service"
            actionButton.setBackgroundColor(getColor(R.color.green))
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val componentName = "$packageName/.TikTokScrollService"
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            if (splitter.next().equals(componentName, ignoreCase = true)) return true
        }
        return false
    }
}
